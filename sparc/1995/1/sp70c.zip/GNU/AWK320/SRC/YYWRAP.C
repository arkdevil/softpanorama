/*
 *  yywrap.c -- default lex termination routine
 *
 * Copyright (C) 1988, 1989, 1990, 1991 by Rob Duff
 * All rights reserved
 */
yywrap()
{
    return(1);
}

