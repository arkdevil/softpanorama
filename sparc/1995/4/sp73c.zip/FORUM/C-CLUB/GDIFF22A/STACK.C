extern unsigned _stklen = 24*1024;
