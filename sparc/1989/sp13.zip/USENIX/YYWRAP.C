yywrap()
{
	return(1);
}
