void ExitProg(int CurSize){
  set_cursor_size(CurSize);
  textbackground(0);textcolor(7);
  clrscr();
  exit(0);
}