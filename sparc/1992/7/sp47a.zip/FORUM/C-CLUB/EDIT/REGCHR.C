int CharDown(char ChIn){
  if((ChIn>='�')&&(ChIn<='�'))
	ChIn+=('�' - '�');
    if((ChIn>='�')&&(ChIn<='�'))
	  ChIn+=('�' - '�');
	if(ChIn=='�')
	     ChIn+=('�' - '�');
	    if((ChIn>='A')&&(ChIn<='Z'))
		  ChIn+=('a' - 'A');
 return (ChIn);
}
int CharUp(char ChIn){
  if((ChIn>='�')&&(ChIn<='�'))
	ChIn-=('�' - '�');
    if((ChIn>='�')&&(ChIn<='�'))
	  ChIn-=('�' - '�');
	if(ChIn=='�')
	     ChIn-=('�' - '�');
	    if((ChIn>='a')&&(ChIn<='z'))
		  ChIn-=('a' - 'A');
 return (ChIn);
}