#ifdef	CUSTOMS
#include "remote-customs.c"
#else	/* Not CUSTOMS.  */
#include "remote-stub.c"
#endif	/* CUSTOMS.  */
