char *version_string = "3.58";

#ifdef MSDOS
char *msdos_version_string = __DATE__ ", " __TIME__;
#endif /* MSDOS */


/*
  Local variables:
  version-control: never
  End:
 */
